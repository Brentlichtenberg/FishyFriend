# Crown Bees — Liquid Glass Design System

This is an iOS 26 Liquid Glass redesign of the Crown Bees solitary bee companion app.

## Core Aesthetic
Liquid Glass: translucent, frosted surfaces that refract the vivid amber and forest-green gradients behind them. Every card, chip, form field, and button is glass. Backgrounds are always rich gradients — never flat colors — so the glass has content to refract.

## Color
- Primary: #E69100 (amber honey)
- Secondary: #306944 (forest green)
- Backgrounds: amber-to-green gradients, deep teal-to-amber gradients
- Glass surfaces: semi-transparent frosted white/clear with subtle inner glow
- Text: always high-contrast on glass (dark on light glass, light on dark glass)

## Glass Language
- Cards: rounded rect glass with subtle white inner stroke (1px, 20% opacity)
- Chips: capsule glass, tinted amber/green when selected
- Buttons: glass capsule for secondary, vibrant amber glass for primary CTA
- Inputs: glass rect fields with frosted interior
- Side menu: full-height glass panel sliding from left
- All glass uses backdrop-blur: 24px

## Typography
- Headlines: Plus Jakarta Sans, bold, tight tracking
- Body: Inter, regular
- Chip labels: Inter medium, small

## Backgrounds
- Home: diagonal amber-to-cream gradient with subtle honeycomb texture overlay
- Journal: deep forest green to mint gradient
- Weather: sky blue to amber gradient (sunrise palette)
- Resources: deep green to sage gradient
- Auth: amber gradient hero (top 40%) transitioning to cream (bottom 60%)
- Side menu open: full-screen backdrop dimmed, glass drawer overlaid